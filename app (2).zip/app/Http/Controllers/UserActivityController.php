<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserTimeLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserActivityController extends Controller
{
    /**
     * Periodic heartbeat from frontend to record active and idle time.
     */
    public function heartbeat(Request $request): JsonResponse
    {
        $user = Auth::user();
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        $today = now()->toDateString();
        $creatorId = method_exists($user, 'creatorId') ? $user->creatorId() : ($user->created_by ?? $user->id);

        $log = UserTimeLog::firstOrCreate(
            [
                'user_id' => $user->id,
                'date' => $today,
            ],
            [
                'created_by' => $creatorId,
                'first_login_at' => now(),
                'status' => 'active',
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]
        );

        $activeDelta = max(0, min(300, (int) $request->input('active_delta', 0)));
        $idleDelta = max(0, min(300, (int) $request->input('idle_delta', 0)));
        $isActive = filter_var($request->input('is_active', true), FILTER_VALIDATE_BOOLEAN);
        $currentUrl = (string) $request->input('current_url', '');

        $log->active_seconds += $activeDelta;
        $log->idle_seconds += $idleDelta;
        $log->total_seconds = $log->active_seconds + $log->idle_seconds;
        $log->status = $isActive ? 'active' : 'idle';
        $log->last_activity_at = now();
        
        if (!empty($currentUrl)) {
            $log->last_active_url = substr($currentUrl, 0, 255);
        }
        $log->save();

        // Update user state
        $user->forceFill([
            'last_activity_at' => now(),
            'current_status' => $isActive ? 'active' : 'idle',
            'current_page' => !empty($currentUrl) ? substr($currentUrl, 0, 255) : $user->current_page,
        ])->save();

        return response()->json([
            'status' => 'success',
            'data' => [
                'today_total_seconds' => $log->total_seconds,
                'today_active_seconds' => $log->active_seconds,
                'today_idle_seconds' => $log->idle_seconds,
                'formatted_total_time' => $log->formatted_total_time,
                'formatted_active_time' => $log->formatted_active_time,
                'formatted_idle_time' => $log->formatted_idle_time,
                'active_percentage' => $log->active_percentage,
                'current_status' => $log->status,
                'first_login_at' => $log->first_login_at ? $log->first_login_at->format('h:i A') : null,
            ]
        ]);
    }

    /**
     * Get initial/today's summary for active session timer initialization.
     */
    public function getTodaySummary(Request $request): JsonResponse
    {
        $user = Auth::user();
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        $today = now()->toDateString();
        $log = UserTimeLog::where('user_id', $user->id)->where('date', $today)->first();

        if (!$log) {
            return response()->json([
                'status' => 'success',
                'data' => [
                    'today_total_seconds' => 0,
                    'today_active_seconds' => 0,
                    'today_idle_seconds' => 0,
                    'formatted_total_time' => '00m 00s',
                    'formatted_active_time' => '00m 00s',
                    'formatted_idle_time' => '00m 00s',
                    'active_percentage' => 0,
                    'current_status' => 'active',
                    'first_login_at' => now()->format('h:i A'),
                ]
            ]);
        }

        return response()->json([
            'status' => 'success',
            'data' => [
                'today_total_seconds' => $log->total_seconds,
                'today_active_seconds' => $log->active_seconds,
                'today_idle_seconds' => $log->idle_seconds,
                'formatted_total_time' => $log->formatted_total_time,
                'formatted_active_time' => $log->formatted_active_time,
                'formatted_idle_time' => $log->formatted_idle_time,
                'active_percentage' => $log->active_percentage,
                'current_status' => $log->status,
                'first_login_at' => $log->first_login_at ? $log->first_login_at->format('h:i A') : null,
            ]
        ]);
    }
}
